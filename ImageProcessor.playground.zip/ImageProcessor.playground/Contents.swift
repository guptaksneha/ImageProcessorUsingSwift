//: Playground - noun: a place where people can play

// Name : Picture Art

import UIKit

// Customisable Filter Enum
enum FilterType : Int {
  case vintage = 0
  case crossProc
  case lomo
  case orton
  case sunny
}

//Default Filter Enum
enum DefaultFilterType : Int {
  case grey = 0
  case inversion
  case solarisation
  case doubleContrast
  case halfBrighty
}

//parameters for filter calculations
struct Parameter {
  var avgRed = 0
  var avgGreen = 0
  var avgBlue = 0
  var incValue = 0
  var contrast = 0
  var brightness = 0
}

// Class for Image Processing
class ImageProcessor {
  
  //properties
  var filterParameter = Parameter()
  var sampleRGBA : RGBAImage!

  //methods
  
  //get Image
  func getImage() {
    let image = UIImage(named: "sample")!
    sampleRGBA = RGBAImage(image: image)!
  }
  
  //Calculate average number of red, green and blue pixels
  func calculateAvgRGB() {
    
    var totalRed = 0
    var totalGreen = 0
    var totalBlue = 0
    
    for y in 0..<sampleRGBA.height {
      for x in 0..<sampleRGBA.width {
        let index = y * sampleRGBA.width + x
        var pixel = sampleRGBA.pixels[index]
        totalRed =  totalRed + Int(pixel.red)
        totalGreen = totalGreen + Int(pixel.green)
        totalBlue = totalBlue + Int(pixel.blue)
      }
    }
    
    let count = sampleRGBA.height * sampleRGBA.width
    filterParameter.avgRed = totalRed/count
    filterParameter.avgGreen = totalGreen/count
    filterParameter.avgBlue = totalBlue/count
  }
  
  //process image depeding on user's choice
  func applyCustomisableFilter(filterOrder : [FilterType] ) -> UIImage {

    getImage() // Initialise image
    imageProcessor.calculateAvgRGB()

    for order in 0..<filterOrder.count {
      for y in 0..<sampleRGBA.height {
        for x in 0..<sampleRGBA.width {
          let index = y * sampleRGBA.width + x
          var pixel = sampleRGBA.pixels[index]
        
          switch (filterOrder[order]) {
        
            case .vintage:
              filterParameter.incValue = 5 //variable filter parameter
              let redDiff = Int(pixel.red) - filterParameter.avgRed
              if(redDiff > 0) {
                pixel.red = UInt8(max(0,min(255, filterParameter.avgRed + redDiff * filterParameter.incValue )))
                sampleRGBA.pixels[index] = pixel
              }
          case .crossProc:
            filterParameter.incValue
            let greenDiff = Int(pixel.green) - filterParameter.avgGreen
            if(greenDiff > 0) {
              pixel.green = UInt8(max(0,min(255, filterParameter.avgGreen + greenDiff * filterParameter.incValue )))
              sampleRGBA.pixels[index] = pixel
            }
 
          case .lomo:
            filterParameter.incValue
            let blueDiff = Int(pixel.blue) - filterParameter.avgBlue
            if(blueDiff > 0) {
              pixel.blue = UInt8(max(0,min(255, filterParameter.avgBlue + blueDiff * filterParameter.incValue )))
              sampleRGBA.pixels[index] = pixel
            }
          
          case .orton:
            filterParameter.contrast = 150
            let factor : Double!
            factor = Double((259 * (filterParameter.contrast + 255)) / (255 * (259 - filterParameter.contrast)))
            pixel.red = UInt8(max(0,min(255,(factor * (Double(pixel.red) - 128) + 128))))
            pixel.green = UInt8(max(0,min(255,(factor * (Double(pixel.green) - 128) + 128))))
            pixel.blue  = UInt8(max(0,min(255,(factor * (Double(pixel.blue)  - 128) + 128))))
            sampleRGBA.pixels[index] = pixel

          case .sunny:
            filterParameter.brightness = 150
            pixel.red = UInt8(max(0,min(255, Int(pixel.red)  + filterParameter.brightness)))
            pixel.green = UInt8(max(0,min(255, Int(pixel.green)  + filterParameter.brightness)))
            pixel.blue  = UInt8(max(0,min(255, Int(pixel.blue)  + filterParameter.brightness)))
            sampleRGBA.pixels[index] = pixel
          
          }
        }
      }
    }
    let processedImage = sampleRGBA.toUIImage()!
    return processedImage
  }
  
  //process image depeding on user's choice for default filter
  // choice: Default filter Name
  func applyDefaultFilter(choice : DefaultFilterType ) -> UIImage {
    
    getImage() // Initialise image
    imageProcessor.calculateAvgRGB()

    for y in 0..<sampleRGBA.height {
      for x in 0..<sampleRGBA.width {
        let index = y * sampleRGBA.width + x
        var pixel = sampleRGBA.pixels[index]
        
        switch(choice) {
          
          case .grey:
            let red : Int = Int(pixel.red)
            let green : Int = Int(pixel.green)
            let blue : Int = Int(pixel.blue)
            let greyValue : UInt8 = UInt8((red+green+blue) / 3)
            pixel.red = greyValue
            pixel.green = greyValue
            pixel.blue = greyValue
            sampleRGBA.pixels[index] = pixel
          
          case .inversion:
            pixel.red = 255 - pixel.red
            pixel.green = 255 - pixel.green
            pixel.blue = 255 - pixel.blue
            sampleRGBA.pixels[index] = pixel
        
          case .solarisation:
            let threshold = 255
            if Int(pixel.red) < threshold {
              pixel.red = 255 - pixel.red
            }
            if Int(pixel.green) < threshold {
              pixel.green = 255 - pixel.green
            }
            if Int(pixel.blue) < threshold {
              pixel.blue = 255 - pixel.blue
            }
            sampleRGBA.pixels[index] = pixel
          
          case .doubleContrast:
            let factor : Double!
            factor = Double((259 * (128 + 255)) / (255 * (259 - 128)))
            pixel.red = UInt8(max(0,min(255,(factor * (Double(pixel.red) - 128) + 128))))
            pixel.green = UInt8(max(0,min(255,(factor * (Double(pixel.green) - 128) + 128))))
            pixel.blue  = UInt8(max(0,min(255,(factor * (Double(pixel.blue)  - 128) + 128))))
            sampleRGBA.pixels[index] = pixel
         
          case .halfBrighty:
            pixel.red = UInt8(max(0,min(255, Int(pixel.red)  + 128)))
            pixel.green = UInt8(max(0,min(255, Int(pixel.green)  + 128)))
            pixel.blue  = UInt8(max(0,min(255, Int(pixel.blue)  + 128)))
            sampleRGBA.pixels[index] = pixel
          }
        }
      }
    let processedImage = sampleRGBA.toUIImage()!
    return processedImage
  }
}

var imageProcessor = ImageProcessor()
//specify filter order
var filterOrder : [FilterType] = [FilterType.vintage, FilterType.orton, FilterType.sunny]

var newImage : UIImage?
//apply customisable image filter
newImage = imageProcessor.applyCustomisableFilter(filterOrder)
//aplly default image filter
newImage = imageProcessor.applyDefaultFilter(DefaultFilterType.grey)






